package controller;

import java.io.IOException;
import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.Booking;
import model.Customer;
import model.Tour;
import services.TourService;

/**
 * Servlet implementation class BookingServlet
 */
@WebServlet("/bookingservlet")
public class BookingServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public BookingServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String name = request.getParameter("name");
		String address = request.getParameter("address");
		String email = request.getParameter("email");
		String phone = request.getParameter("phone");
		String dayStart = request.getParameter("dayStart");
		String nguoilon = request.getParameter("nguoilon");
		String treem = request.getParameter("treem");

		HttpSession session = request.getSession();
		Tour tour = (Tour) session.getAttribute("tour");

		SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
		java.util.Date parsedDate;
		Date sqlDate = null;
		try {
			parsedDate = dateFormat.parse(dayStart);
			sqlDate = new Date(parsedDate.getTime());
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
         

		Customer customer = new Customer(name, address, email, phone);
		Booking booking = new Booking(customer, sqlDate, Integer.parseInt(nguoilon), Integer.parseInt(treem), tour);
		TourService tourService = new TourService();
		tourService.saveCustomer(customer);
		tourService.saveBooking(booking);
		session.setAttribute("customer", customer);
		session.setAttribute("booking", booking);
		RequestDispatcher rd = request.getRequestDispatcher("/confirm.jsp");
		rd.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
