package controller;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.Calendar;
import java.util.Collection;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.AuctionItem;
import model.Bid;
import service.AuctionService;

/**
 * Servlet implementation class ShowTopic
 */
@WebServlet("/ShowTopic")
public class ShowTopic extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ShowTopic() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String rqID = request.getParameter("auction");
		Long id = Long.parseLong(rqID);
		
		HttpSession session = request.getSession();
		Bid bid = null;
		Calendar calenderStart = null;
		Calendar calenderEnd = null;
		
		AuctionService service = new AuctionService();
		AuctionItem auctionItem = service.getAuctionItem(id);
		session.setAttribute("auction", auctionItem);
		bid = auctionItem.getLastBid();
		calenderStart = auctionItem.getStartDate();
		calenderEnd = auctionItem.getEndDate();
		
//		for (AuctionItem auctionItem : listAuction) {
//			if(auctionItem.getId() == id) {
//				session.setAttribute("auction", auctionItem);
//				bid = auctionItem.getLastBid();
//				calenderStart = auctionItem.getStartDate();
//				calenderEnd = auctionItem.getEndDate();
//			}
//		}
		if(bid == null) {
			session.setAttribute("bidUsername", "");
		}else {
			session.setAttribute("bidUsername", bid.getBidder().getUsername());
		}
		double currentPrice = 0;
	
		SimpleDateFormat dateFormat = new SimpleDateFormat("HH:mm:ss 'Ngày' dd/MM/yyyy");
		String formattedDate = dateFormat.format(calenderStart.getTime());
		System.out.println(formattedDate);
		session.setAttribute("startDate", formattedDate);
		formattedDate = dateFormat.format(calenderEnd.getTime());
		session.setAttribute("endDate", formattedDate);
		model.Duration duration = new model.Duration(calenderStart, calenderEnd);
		session.setAttribute("duration", duration.toString());
		RequestDispatcher rd = request.getRequestDispatcher("/showTopic.jsp");
		rd.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
