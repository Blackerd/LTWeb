package model;

public class Message extends Entry {
   public Message(String title, String content, User creator) {
      super(title, content, creator);
   }

}
