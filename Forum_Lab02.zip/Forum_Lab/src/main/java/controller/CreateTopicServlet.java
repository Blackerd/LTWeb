package controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.Topic;
import model.User;
import service.ForumService;

/**
 * Servlet implementation class CreateTopicServlet
 */
@WebServlet("/createtopicservlet")
public class CreateTopicServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CreateTopicServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String title = request.getParameter("title");
		String content = request.getParameter("content");
		ForumService forumService = ForumService.getInstance();
		HttpSession session = request.getSession();
		int id = forumService.getTopics().size() + 1;
		User user = (User) session.getAttribute("user");
		
		if(!title.equals(null) && !content.equals(null)) {
			Topic topic = new Topic(id, title, content, user, null);
			forumService.getTopic().put(id, topic);
		}
		
		RequestDispatcher rd = request.getRequestDispatcher("/listopic.jsp");
		rd.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
